# WAES-CW-1

users: school pupils

problem: need info on satellites to write essays

uniqueness: easy to understand and interactive making learning fun


aimed at school children writing essays on space (well rounded, easy to understand)
generates interest in space
informative

1 stop shop for credible reliable but also easy to inderstand information on satellites. 
an informative interactive edjutainment website aimed at young pupils interested in space covering the current usage, history andhow to get involved.

possible color pallet

Ebony Clay
#282C44

Pewter
#A1A5A1

Pharlap
#A07E6E

Lynch
#75889E

python3 -m http.server